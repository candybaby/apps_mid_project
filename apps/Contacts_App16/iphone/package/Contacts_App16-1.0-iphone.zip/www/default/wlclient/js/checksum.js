var WL_CHECKSUM = {"checksum":1602552256,"date":1397751886985,"machine":"candytekiMacBook-Pro.local"};
/* Date: Fri Apr 18 00:24:46 CST 2014 */